package br.ucb.modelo.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.ucb.modelo.Creche;
import br.ucb.modelo.Doador;

public class DAO implements Serializable{

	private static final long serialVersionUID = 1L;
	private Connection con;
	
	public DAO() throws SQLException {
			this.con = ConnectionFactory.getConnection();
	}
	
	public int cadastrar(Doador doador) throws SQLException{
		if (doador == null)
			return 0;
		String sql="INSERT INTO doador (nome,telefone,email) VALUES (?, ?, ?);";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,doador.getNome());
		stmt.setString(2,doador.getTelefone());
		stmt.setString(3,doador.getEmail());
		
		int retorno = stmt.executeUpdate();
		stmt.close();
		return retorno;
	}
	
	public int cadastrarCreche(Creche creche) throws SQLException{
		if(creche == null)
			return 0;
		String sql = "INSERT INTO creche (cnpj, nomeCreche, nomeResponsavel, email, telefone, necessidadePrincipal, endereco) VALUES (?, ?, ?, ?, ?, ?, ?);";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,creche.getCnpj());
		stmt.setString(2,creche.getNomeCreche());
		stmt.setString(3,creche.getNomeResponsavel());
		stmt.setString(4,creche.getEmail());
		stmt.setString(5,creche.getTelefone());
		stmt.setString(6,creche.getNecessidadePrincipal());
		stmt.setString(7,creche.getEndereco());
		
		int retorno = stmt.executeUpdate();
		 stmt.close();
		return retorno;
		
	}
	
}
