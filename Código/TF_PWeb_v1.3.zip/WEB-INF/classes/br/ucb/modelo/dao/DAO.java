package br.ucb.modelo.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.ucb.modelo.Creche;
import br.ucb.modelo.Doador;

public class DAO implements Serializable{

	private static final long serialVersionUID = 1L;
	private Connection con;
	
	public DAO() throws SQLException {
			this.con = ConnectionFactory.getConnection();
	}
	
	public int cadastrar(Doador doador) throws SQLException{
		if (doador == null)
			return 0;
		String sql="INSERT INTO doador (nome,telefone,email,senha) VALUES (?, ?, ?, ?);";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,doador.getNome());
		stmt.setString(2,doador.getTelefone());
		stmt.setString(3,doador.getEmail());
		stmt.setString(4,doador.getSenha());
		
		int retorno = stmt.executeUpdate();
		stmt.close();
		return retorno;
	}
	
	public int cadastrarCreche(Creche creche) throws SQLException{
		if(creche == null)
			return 0;
		String sql = "INSERT INTO creche (cnpj, nomeCreche, nomeResponsavel, email, telefone, necessidadePrincipal, endereco, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,creche.getCnpj());
		stmt.setString(2,creche.getNomeCreche());
		stmt.setString(3,creche.getNomeResponsavel());
		stmt.setString(4,creche.getEmail());
		stmt.setString(5,creche.getTelefone());
		stmt.setString(6,creche.getNecessidadePrincipal());
		stmt.setString(7,creche.getEndereco());
		stmt.setString(8,creche.getSenha());
		
		int retorno = stmt.executeUpdate();
		 stmt.close();
		return retorno;
		
	}
	
	public Doador logarDoador(Doador doador) throws SQLException{
		if(doador == null)
			return null;
		
		String sql = "SELECT * FROM doador WHERE email = ? AND senha = ? ; ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, doador.getEmail());
		stmt.setString(2,doador.getSenha());
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			
			doador = new Doador();
			doador.setId(rs.getLong("id"));
			doador.setNome(rs.getString("nome"));
			doador.setEmail(rs.getString("email"));
			doador.setTelefone(rs.getString("telefone"));
			doador.setSenha(rs.getString("senha"));
			
		}
		System.out.println("Sucesso!");
		
		return doador;
	}
	public Creche logarCreche(Creche creche) throws SQLException{
		if(creche == null)
			return null;
		
		String sql = "SELECT * FROM creche WHERE email = ? AND senha = ? ; ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1, creche.getEmail());
		stmt.setString(2,creche.getSenha());
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			
			creche = new Creche();
			creche.setId(rs.getLong("id"));
			creche.setCnpj(rs.getString("cnpj"));
			creche.setNomeCreche(rs.getString("nomeCreche"));
			creche.setNomeResponsavel("nomeResponsavel");
			creche.setEmail(rs.getString("email"));
			creche.setEndereco(rs.getString("endereco"));
			creche.setTelefone(rs.getString("telefone"));
			creche.setNecessidadePrincipal(rs.getString("necessidadePrincipal"));
			creche.setSenha(rs.getString("senha"));
			
		}
		System.out.println("Sucesso!");
		
		return creche;
	}
		
}
