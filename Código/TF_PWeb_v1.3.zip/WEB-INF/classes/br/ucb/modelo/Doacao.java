package br.ucb.modelo;

import java.io.Serializable;

public class Doacao implements Serializable{
private static final long serialVersionUID = 1L;
	
	private String tipoDoacao;
	private String dataDoacao;
	private long id;
	public Doacao() {
		
	}
	
	public String getTipoDoacao() {
		return tipoDoacao;
	}

	public void setTipoDoacao(String tipoDoacao) {
		this.tipoDoacao = tipoDoacao;
	}

	public String getDataDoacao() {
		return dataDoacao;
	}

	public void setDataDoacao(String dataDoacao) {
		this.dataDoacao = dataDoacao;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
	
}
