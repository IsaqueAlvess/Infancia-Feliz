package br.ucb.controle;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.ucb.modelo.*;
import br.ucb.modelo.dao.DAO;


@WebServlet("/crudControl")
public class CRUD extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String acao = request.getParameter("acao"), destino=null;
		RequestDispatcher dispatcher;
		
		Doador doador;
		Creche creche;
		
		try {
		DAO dao = new DAO(); // <---
			//Inclus�o doador
			//acao.equals("doador/creche"); - reutilizar m�todo em 2 if's
	
		if(acao.equals("doador")){
		doador = new Doador();
		doador.setNome(request.getParameter("nomeDoador"));
		doador.setTelefone(request.getParameter("telefoneDoador"));
		doador.setEmail(request.getParameter("email"));
		doador.setSenha(request.getParameter("senha"));
			if (dao.cadastrar(doador) == 0) {
				request.setAttribute("erro", "Erro no cadastro. Tente novamente!");
				destino="cadastroDoador.jsp";
			}
			else {
				request.setAttribute("mensagem", "Cadastro conclu�do com sucesso!");
				destino="index.jsp";
			}
		}else if(acao.equals("creche")) {
			creche = new Creche();
			creche.setCnpj(request.getParameter("cnpj"));
			creche.setNomeCreche(request.getParameter("nomeCreche"));
			creche.setNomeResponsavel(request.getParameter("nomeResponsavel"));
			creche.setEmail(request.getParameter("email"));
			creche.setTelefone(request.getParameter("telefone"));
			creche.setEndereco(request.getParameter("endereco"));
			creche.setNecessidadePrincipal(request.getParameter("necessidadePrincipal"));
			creche.setSenha(request.getParameter("senha"));
			
			if (dao.cadastrarCreche(creche) == 0) {
				request.setAttribute("erro", "Erro no cadastro. Tente novamente!");
				destino="cadastroInstituicao.jsp";
			}
					else {
						request.setAttribute("mensagem", "Cadastro conclu�do com sucesso!");
						destino="index.jsp";
					}
		}else if(acao.equals("loginDoador")) {
			doador=new Doador();
			
			doador = dao.logarDoador(doador);
			request.setAttribute("doador", doador);
		
			if (dao.logarDoador(doador) == null) {
				request.setAttribute("erro", "Usu�rio/Senha inv�lido. Tente novamente!");
				destino="loginDoador.jsp";
			}else 
				destino="perfilDoador.jsp";

		}else if(acao.equals("loginCreche")) {
			creche = new Creche();
			
			creche = dao.logarCreche(creche);
			request.setAttribute("creche",creche);
			
			if(dao.logarCreche(creche)==null) {
				request.setAttribute("erro","Usu�rio/Senha inv�lido. Tente novamente!");
				destino="loginCreche.jsp"; //criar
			}else
				destino="perfilCreche_creche.jsp";
			
		}
		
		
		} catch (SQLException e) {
			request.setAttribute("erro", "Erro de banco de dados");
			destino = "index.jsp"; 
		} 
		dispatcher = request.getRequestDispatcher(destino);
		dispatcher.forward(request, response);
		
	}

}
